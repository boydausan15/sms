/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Key, Code, Activity, Plus, Copy, CheckCircle2, MessageSquare, Terminal, Send, AlertCircle, Loader2, Smartphone } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'logs' | 'keys' | 'docs' | 'gateway'>('logs');
  const [keys, setKeys] = useState<string[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [copied, setCopied] = useState('');

  const [testTo, setTestTo] = useState('');
  const [testFrom, setTestFrom] = useState('');
  const [testBody, setTestBody] = useState('');
  const [testStatus, setTestStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [testFeedback, setTestFeedback] = useState('');

  useEffect(() => {
    fetchKeys();
    fetchLogs();
    // Poll for new logs every 3 seconds
    const interval = setInterval(fetchLogs, 3000);
    return () => clearInterval(interval);
  }, []);

  const fetchKeys = async () => {
    try {
      const res = await fetch('/api/internal/keys');
      if (!res.ok) return;
      const data = await res.json();
      setKeys(data.keys || []);
    } catch (e) {
      // Silently ignore network errors during polling (e.g., when server restarts)
    }
  };

  const fetchLogs = async () => {
    try {
      const res = await fetch('/api/internal/logs');
      if (!res.ok) return;
      const data = await res.json();
      setLogs(data.logs || []);
    } catch (e) {
      // Silently ignore network errors during polling (e.g., when server restarts)
    }
  };

  const generateKey = async () => {
    try {
      await fetch('/api/internal/keys', { method: 'POST' });
      fetchKeys();
    } catch (e) {
      console.error("Failed to generate key");
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(text);
    setTimeout(() => setCopied(''), 2000);
  };

  const handleTestSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (keys.length === 0) {
      setTestStatus('error');
      setTestFeedback('Please generate an API key first in the API Keys tab.');
      return;
    }
    if (!testTo || !testBody) {
      setTestStatus('error');
      setTestFeedback('Please provide both a recipient number and a message body.');
      return;
    }

    setTestStatus('loading');
    setTestFeedback('');

    try {
      const response = await fetch('/api/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${keys[0]}`
        },
        body: JSON.stringify({ to: testTo, from: testFrom, body: testBody }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to send test message');
      }

      setTestStatus('success');
      setTestFeedback(`Test message queued successfully! ID: ${data.id}`);
      setTestTo('');
      setTestFrom('');
      setTestBody('');
      fetchLogs();
    } catch (err: any) {
      setTestStatus('error');
      setTestFeedback(err.message || 'An unexpected error occurred.');
    }
  };

  return (
    <div className="min-h-screen bg-neutral-50 flex font-sans text-neutral-900">
      {/* Sidebar */}
      <div className="w-64 bg-white border-r border-neutral-200 flex flex-col fixed h-full">
        <div className="p-6 border-b border-neutral-200 flex items-center gap-3">
          <div className="bg-blue-600 p-2 rounded-lg">
            <MessageSquare className="w-5 h-5 text-white" />
          </div>
          <h1 className="font-bold text-lg tracking-tight">SMS Provider</h1>
        </div>
        <nav className="flex-1 p-4 space-y-1">
          <button 
            onClick={() => setActiveTab('logs')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${activeTab === 'logs' ? 'bg-blue-50 text-blue-700' : 'text-neutral-600 hover:bg-neutral-100'}`}
          >
            <Activity className="w-4 h-4" />
            Message Logs
          </button>
          <button 
            onClick={() => setActiveTab('keys')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${activeTab === 'keys' ? 'bg-blue-50 text-blue-700' : 'text-neutral-600 hover:bg-neutral-100'}`}
          >
            <Key className="w-4 h-4" />
            API Keys
          </button>
          <button 
            onClick={() => setActiveTab('docs')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${activeTab === 'docs' ? 'bg-blue-50 text-blue-700' : 'text-neutral-600 hover:bg-neutral-100'}`}
          >
            <Code className="w-4 h-4" />
            Documentation
          </button>
          <button 
            onClick={() => setActiveTab('gateway')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${activeTab === 'gateway' ? 'bg-blue-50 text-blue-700' : 'text-neutral-600 hover:bg-neutral-100'}`}
          >
            <Smartphone className="w-4 h-4" />
            Android Gateway
          </button>
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-8 ml-64">
        <div className="max-w-5xl mx-auto space-y-6">
          
          {activeTab === 'logs' && (
            <div className="space-y-6 animate-in fade-in duration-300">
              <div>
                <h2 className="text-2xl font-bold tracking-tight">Message Logs</h2>
                <p className="text-neutral-500 mt-1">View all messages sent by your customers through your API.</p>
              </div>
              <div className="bg-white border border-neutral-200 rounded-2xl shadow-sm overflow-hidden">
                <table className="w-full text-left text-sm">
                  <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-500">
                    <tr>
                      <th className="px-6 py-4 font-medium">Message ID</th>
                      <th className="px-6 py-4 font-medium">To</th>
                      <th className="px-6 py-4 font-medium">From</th>
                      <th className="px-6 py-4 font-medium">Body</th>
                      <th className="px-6 py-4 font-medium">Status</th>
                      <th className="px-6 py-4 font-medium">Time</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100">
                    {logs.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="px-6 py-8 text-center text-neutral-500">No messages sent yet.</td>
                      </tr>
                    ) : (
                      logs.map((log) => (
                        <tr key={log.id} className="hover:bg-neutral-50/50">
                          <td className="px-6 py-4 font-mono text-xs text-neutral-600">{log.id}</td>
                          <td className="px-6 py-4 font-medium">{log.to}</td>
                          <td className="px-6 py-4 text-neutral-600">{log.from}</td>
                          <td className="px-6 py-4 text-neutral-600 max-w-xs truncate">{log.body}</td>
                          <td className="px-6 py-4">
                            <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800">
                              {log.status}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-neutral-500">{new Date(log.timestamp).toLocaleString()}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'keys' && (
            <div className="space-y-6 animate-in fade-in duration-300">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-bold tracking-tight">API Keys</h2>
                  <p className="text-neutral-500 mt-1">Manage API keys for your customers to authenticate their requests.</p>
                </div>
                <button 
                  onClick={generateKey}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-xl text-sm font-medium flex items-center gap-2 transition-colors shadow-sm shadow-blue-600/20"
                >
                  <Plus className="w-4 h-4" />
                  Generate New Key
                </button>
              </div>
              <div className="grid gap-4">
                {keys.map(key => (
                  <div key={key} className="bg-white border border-neutral-200 p-5 rounded-2xl shadow-sm flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="bg-neutral-100 p-3 rounded-xl">
                        <Key className="w-5 h-5 text-neutral-600" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-neutral-900">Standard API Key</p>
                        <p className="text-sm font-mono text-neutral-500 mt-0.5">{key}</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => copyToClipboard(key)}
                      className="p-2 text-neutral-400 hover:text-neutral-900 hover:bg-neutral-100 rounded-lg transition-colors"
                      title="Copy to clipboard"
                    >
                      {copied === key ? <CheckCircle2 className="w-5 h-5 text-emerald-600" /> : <Copy className="w-5 h-5" />}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'docs' && (
            <div className="space-y-6 animate-in fade-in duration-300">
              <div>
                <h2 className="text-2xl font-bold tracking-tight">API Documentation</h2>
                <p className="text-neutral-500 mt-1">Share this with your customers so they can integrate your SMS API.</p>
              </div>
              
              <div className="bg-white border border-neutral-200 rounded-2xl shadow-sm overflow-hidden">
                <div className="border-b border-neutral-200 bg-neutral-50 px-6 py-4 flex items-center gap-3">
                  <Terminal className="w-5 h-5 text-neutral-500" />
                  <h3 className="font-medium">Send an SMS</h3>
                </div>
                <div className="p-6 space-y-6">
                  <div>
                    <div className="flex items-center gap-3 mb-4">
                      <span className="bg-blue-100 text-blue-800 text-xs font-bold px-2.5 py-1 rounded">POST</span>
                      <code className="text-sm font-mono text-neutral-700">/api/v1/messages</code>
                    </div>
                    <p className="text-sm text-neutral-600">Send a text message to a specific phone number.</p>
                  </div>

                  <div className="space-y-3">
                    <h4 className="text-sm font-semibold text-neutral-900">cURL Example</h4>
                    <div className="bg-neutral-900 rounded-xl p-4 relative group">
                      <pre className="text-sm font-mono text-neutral-300 overflow-x-auto">
                        <code>{`curl -X POST ${window.location.origin}/api/v1/messages \\
  -H "Authorization: Bearer ${keys[0] || 'YOUR_API_KEY'}" \\
  -H "Content-Type: application/json" \\
  -d '{
    "to": "+1234567890",
    "from": "MyCompany",
    "body": "Hello from the new SMS API!"
  }'`}</code>
                      </pre>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h4 className="text-sm font-semibold text-neutral-900">Response</h4>
                    <div className="bg-neutral-900 rounded-xl p-4">
                      <pre className="text-sm font-mono text-emerald-400">
                        <code>{`{
  "id": "msg_a1b2c3d4",
  "status": "queued",
  "to": "+1234567890",
  "from": "MyCompany"
}`}</code>
                      </pre>
                    </div>
                  </div>
                </div>
              </div>

              {/* Interactive API Tester */}
              <div className="bg-white border border-neutral-200 rounded-2xl shadow-sm overflow-hidden mt-6">
                <div className="border-b border-neutral-200 bg-neutral-50 px-6 py-4 flex items-center gap-3">
                  <Activity className="w-5 h-5 text-neutral-500" />
                  <h3 className="font-medium">Interactive API Tester</h3>
                </div>
                <div className="p-6">
                  <form onSubmit={handleTestSubmit} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-sm font-medium text-neutral-700">To</label>
                        <input
                          type="tel"
                          placeholder="+1234567890"
                          value={testTo}
                          onChange={(e) => setTestTo(e.target.value)}
                          className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-sm font-medium text-neutral-700">From (Optional)</label>
                        <input
                          type="text"
                          placeholder="MyCompany"
                          value={testFrom}
                          onChange={(e) => setTestFrom(e.target.value)}
                          className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
                        />
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-sm font-medium text-neutral-700">Message Body</label>
                      <textarea
                        rows={3}
                        placeholder="Test message..."
                        value={testBody}
                        onChange={(e) => setTestBody(e.target.value)}
                        className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all resize-none"
                      />
                    </div>

                    {testFeedback && (
                      <div className={`p-3 rounded-lg text-sm flex items-start gap-2 ${
                        testStatus === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 
                        'bg-red-50 text-red-700 border border-red-100'
                      }`}>
                        {testStatus === 'success' ? <CheckCircle2 className="w-4 h-4 mt-0.5" /> : <AlertCircle className="w-4 h-4 mt-0.5" />}
                        <p>{testFeedback}</p>
                      </div>
                    )}

                    <button
                      type="submit"
                      disabled={testStatus === 'loading'}
                      className="bg-neutral-900 hover:bg-neutral-800 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors disabled:opacity-70 flex items-center gap-2"
                    >
                      {testStatus === 'loading' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                      Send Test Message
                    </button>
                  </form>
                </div>
              </div>

            </div>
          )}

          {activeTab === 'gateway' && (
            <div className="space-y-6 animate-in fade-in duration-300">
              <div>
                <h2 className="text-2xl font-bold tracking-tight">Android Gateway Setup</h2>
                <p className="text-neutral-500 mt-1">Use an Android phone as your physical sending gateway.</p>
              </div>
              
              <div className="bg-white border border-neutral-200 rounded-2xl shadow-sm p-6 mb-8">
                <h3 className="text-lg font-semibold text-neutral-900 mb-4">How it works</h3>
                <p className="text-neutral-600 mb-4">
                  Instead of paying a cloud provider like Twilio, you can use an Android phone with an unlimited SMS plan as your physical sending gateway.
                  Your customers send messages to this API, and your Android phone will automatically fetch them and send them out.
                </p>
                
                <div className="bg-blue-50 p-4 rounded-xl border border-blue-100 mb-6">
                  <h4 className="font-medium text-blue-800 mb-2">Architecture:</h4>
                  <ol className="list-decimal list-inside text-blue-700 space-y-1.5 text-sm">
                    <li>Customer calls <code className="bg-blue-100 px-1.5 py-0.5 rounded font-mono">POST /api/v1/messages</code></li>
                    <li>Message is added to the Pending Queue</li>
                    <li>Android App polls <code className="bg-blue-100 px-1.5 py-0.5 rounded font-mono">GET /api/gateway/pending</code></li>
                    <li>Android App sends the SMS via its local SIM card</li>
                    <li>Android App reports back to <code className="bg-blue-100 px-1.5 py-0.5 rounded font-mono">POST /api/gateway/status</code></li>
                  </ol>
                </div>

                <h3 className="text-lg font-semibold text-neutral-900 mb-4">Gateway Credentials</h3>
                <p className="text-sm text-neutral-500 mb-4">
                  Configure your Android Gateway App (like SMS Gateway API or a custom app) to point to this server using the following credentials:
                </p>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-neutral-700 mb-1.5">Server URL</label>
                    <code className="block w-full bg-neutral-50 p-3 rounded-xl border border-neutral-200 text-sm font-mono text-neutral-800">
                      {window.location.origin}
                    </code>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-neutral-700 mb-1.5">Gateway Secret (Bearer Token)</label>
                    <code className="block w-full bg-neutral-50 p-3 rounded-xl border border-neutral-200 text-sm font-mono text-neutral-800">
                      my_secret_gateway_key_123
                    </code>
                    <p className="text-xs text-neutral-500 mt-2">
                      * You can change this by setting the <code className="bg-neutral-100 px-1 rounded">GATEWAY_SECRET</code> environment variable on your server.
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-white border border-neutral-200 rounded-2xl shadow-sm p-6">
                <h3 className="text-lg font-semibold text-neutral-900 mb-4">API Endpoints for Android App</h3>
                
                <div className="mb-6">
                  <h4 className="font-medium text-neutral-900 mb-2 flex items-center">
                    <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-2 py-1 rounded mr-3">GET</span>
                    <code className="font-mono text-sm">/api/gateway/pending</code>
                  </h4>
                  <p className="text-sm text-neutral-600 mb-3">Fetches all pending messages that need to be sent.</p>
                  <div className="bg-neutral-900 text-neutral-100 p-4 rounded-xl overflow-x-auto text-sm font-mono">
                    <pre>
{`curl -X GET ${window.location.origin}/api/gateway/pending \\
  -H "Authorization: Bearer my_secret_gateway_key_123" \\
  -H "Accept: application/json"`}
                    </pre>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium text-neutral-900 mb-2 flex items-center">
                    <span className="bg-blue-100 text-blue-800 text-xs font-bold px-2 py-1 rounded mr-3">POST</span>
                    <code className="font-mono text-sm">/api/gateway/status</code>
                  </h4>
                  <p className="text-sm text-neutral-600 mb-3">Updates the status of a message after the phone attempts to send it.</p>
                  <div className="bg-neutral-900 text-neutral-100 p-4 rounded-xl overflow-x-auto text-sm font-mono">
                    <pre>
{`curl -X POST ${window.location.origin}/api/gateway/status \\
  -H "Authorization: Bearer my_secret_gateway_key_123" \\
  -H "Content-Type: application/json" \\
  -d '{
    "id": "msg_1234567890abcdef",
    "status": "delivered" // or "failed"
  }'`}
                    </pre>
                  </div>
                </div>
              </div>

              {/* Termux Setup Guide */}
              <div className="bg-white border border-neutral-200 rounded-2xl shadow-sm p-6 mt-8">
                <h3 className="text-xl font-bold text-neutral-900 mb-4 flex items-center gap-2">
                  <Smartphone className="w-6 h-6 text-blue-600" />
                  How to connect your phone (The Easy Way)
                </h3>
                <p className="text-neutral-600 mb-6">
                  The easiest way to turn your Android phone into a gateway without building a full Android app from scratch is using <strong>Termux</strong> (a free terminal emulator for Android).
                </p>

                <div className="space-y-6">
                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-blue-100 text-blue-700 rounded-full flex items-center justify-center font-bold">1</div>
                    <div>
                      <h4 className="font-semibold text-neutral-900">Install Termux & Termux:API</h4>
                      <p className="text-sm text-neutral-600 mt-1">
                        Download both apps from <a href="https://f-droid.org/packages/com.termux/" target="_blank" rel="noreferrer" className="text-blue-600 hover:underline">F-Droid</a> (the Google Play Store version is outdated).
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-blue-100 text-blue-700 rounded-full flex items-center justify-center font-bold">2</div>
                    <div className="w-full">
                      <h4 className="font-semibold text-neutral-900">Install Python & API tools</h4>
                      <p className="text-sm text-neutral-600 mt-1 mb-2">Open the Termux app on your phone and run these commands:</p>
                      <div className="bg-neutral-900 text-neutral-100 p-3 rounded-lg text-sm font-mono overflow-x-auto">
                        <pre>pkg update && pkg install python termux-api -y{'\n'}pip install requests</pre>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-blue-100 text-blue-700 rounded-full flex items-center justify-center font-bold">3</div>
                    <div className="w-full">
                      <h4 className="font-semibold text-neutral-900">Create the Gateway Script</h4>
                      <p className="text-sm text-neutral-600 mt-1 mb-2">In Termux, type <code className="bg-neutral-100 px-1 rounded">nano gateway.py</code> and paste the following code:</p>
                      <div className="bg-neutral-900 text-neutral-100 p-4 rounded-lg text-xs font-mono overflow-x-auto">
                        <pre>{`import requests
import time
import subprocess

# IMPORTANT: Use your PUBLIC Shared App URL here so Termux isn't blocked by a login screen.
SERVER_URL = "https://ais-pre-cqe6iz5ebe224ewtmnmk6w-703828163981.asia-southeast1.run.app"
GATEWAY_SECRET = "my_secret_gateway_key_123"

def check_and_send():
    headers = {
        "Authorization": f"Bearer {GATEWAY_SECRET}",
        "User-Agent": "curl/7.81.0",
        "Accept": "application/json"
    }
    try:
        # 1. Fetch pending messages
        res = requests.get(f"{SERVER_URL}/api/gateway/pending", headers=headers)
        
        if res.status_code != 200:
            print(f"Server Error {res.status_code}: {res.text[:100]}")
            return
            
        try:
            data = res.json()
        except ValueError:
            print("Error: Received HTML instead of JSON. Your SERVER_URL is incorrect or private.")
            return
        
        for msg in data.get("messages", []):
            print(f"Sending to {msg['to']}...")
            
            # 2. Send SMS using Android's native SMS manager
            result = subprocess.run(
                ["termux-sms-send", "-n", msg['to'], msg['body']],
                capture_output=True, text=True
            )
            
            # 3. Report status back to your server
            status = "delivered" if result.returncode == 0 else "failed"
            requests.post(
                f"{SERVER_URL}/api/gateway/status",
                headers=headers,
                json={"id": msg['id'], "status": status, "error": result.stderr}
            )
            time.sleep(2) # Anti-spam delay
            
    except Exception as e:
        print("Connection error:", e)

print("Gateway listening for messages...")
while True:
    check_and_send()
    time.sleep(5) # Check every 5 seconds`}</pre>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-blue-100 text-blue-700 rounded-full flex items-center justify-center font-bold">4</div>
                    <div className="w-full">
                      <h4 className="font-semibold text-neutral-900">Run the Gateway!</h4>
                      <p className="text-sm text-neutral-600 mt-1 mb-2">Save the file (Ctrl+O, Enter, Ctrl+X) and run it:</p>
                      <div className="bg-neutral-900 text-neutral-100 p-3 rounded-lg text-sm font-mono overflow-x-auto">
                        <pre>python gateway.py</pre>
                      </div>
                      <p className="text-sm text-emerald-600 mt-2 font-medium">
                        Your phone is now connected! Any messages sent to your API will be automatically texted out by your phone.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
